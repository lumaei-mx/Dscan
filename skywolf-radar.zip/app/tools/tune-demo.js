'use strict';
/* Calibra las trayectorias sintéticas: comprueba que las velocidades y los
 * regímenes de giro sean físicamente plausibles antes de fijarlas en server.js */
const { TrackStore, analyzeTrack } = require('../lib/detector');

const D = Math.PI / 180;
const paths = {
  fpv: (t) => {
    const x = 380 * Math.sin(0.05 * t) + 55 * Math.sin(0.85 * t);
    const y = 380 * Math.cos(0.05 * t) + 55 * Math.cos(1.05 * t);
    return { x, y, alt: 250 + 150 * Math.sin(0.25 * t) + 40 * Math.sin(1.6 * t) };
  },
  hover: (t) => ({
    x: 320 + 2.5 * Math.sin(0.35 * t),
    y: -420 + 2 * Math.cos(0.29 * t),
    alt: 180 + 110 * Math.sin(0.3 * t) + 25 * Math.sin(2.2 * t),
  }),
  longrange: (t) => {
    const ang = 0.22 * t;
    const r = 180 + 30 * Math.sin(0.13 * t);
    return { x: Math.cos(ang) * r + 12 * t, y: Math.sin(ang) * r, alt: 3000 + 240 * Math.sin(0.26 * t) };
  },
};

for (const [name, fn] of Object.entries(paths)) {
  const store = new TrackStore();
  const lat = 40.4168, lon = -3.7038;
  const dLat = (m) => m / 111320;
  const dLon = (m) => m / (111320 * Math.cos(lat * D));
  const t0 = 1_700_000_000;
  for (let i = 0; i < 30; i++) {
    const t = i * 4;
    const p = fn(t);
    const p2 = fn(t + 0.5);
    const speedMs = Math.hypot(p2.x - p.x, p2.y - p.y) / 0.5;
    const vrate = ((p2.alt - p.alt) / 0.5) * 60;
    store.observe(
      {
        hex: name, lat: lat + dLat(p.y), lon: lon + dLon(p.x), altFt: p.alt + 2185,
        altBaroFt: p.alt + 2185, gsKt: +(speedMs * 1.943844).toFixed(1), track: null, vrateFpm: Math.round(vrate), roll: null,
        callsign: null, reg: null, mlatOnly: name === 'longrange', onGround: false, category: null,
      },
      (t0 + t) * 1000
    );
  }
  const tr = store.get(name);
  const a = analyzeTrack(tr, undefined, 2185);
  console.log(`\n== ${name} score=${a.score} ${a.level} profile=${a.profile}`);
  console.log(JSON.stringify(a.metrics));
  a.evidences.forEach((e) => console.log('  ', e.pts, e.text));
}
