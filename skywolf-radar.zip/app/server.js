'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');
const { scan, SOURCE_DEFS } = require('./lib/sources');
const { TrackStore, analyzeTrack, assessSpoof, haversineM, bearingDeg } = require('./lib/detector');

const PORT = Number(process.env.PORT || 8080);
const ROOT = path.join(__dirname, 'public');

const store = new TrackStore();
const elevationCache = new Map();

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.webmanifest': 'application/manifest+json',
  '.ico': 'image/x-icon',
};

function json(res, code, body) {
  const data = JSON.stringify(body);
  res.writeHead(code, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Access-Control-Allow-Origin': '*',
  });
  res.end(data);
}

async function getElevation(lat, lon) {
  const key = `${lat.toFixed(3)},${lon.toFixed(3)}`;
  const hit = elevationCache.get(key);
  if (hit && Date.now() - hit.t < 86400000) return hit.v;
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 6000);
    const r = await fetch(`https://api.open-meteo.com/v1/elevation?latitude=${lat.toFixed(4)}&longitude=${lon.toFixed(4)}`, { signal: ctrl.signal });
    clearTimeout(timer);
    const j = await r.json();
    const v = Array.isArray(j.elevation) ? j.elevation[0] * 3.280839895 : 0;
    elevationCache.set(key, { t: Date.now(), v });
    return v;
  } catch (_) {
    return 0;
  }
}

/* ------------------------- escenario sintético ------------------------- */

const demoState = { t0: Date.now() };

/**
 * Escenario sintético calibrado: cada trayectoria se define en metros sobre el
 * punto central y se muestrea con diferencias finitas para derivar rumbo,
 * velocidad y régimen vertical coherentes (nada de valores imposibles).
 * La altitud es AGL; se le suma la elevación del terreno.
 */
const DEMO_PATHS = [
  {
    id: 1,
    label: 'FPV de carreras (sintético)',
    sensor: 'ADS-B',
    fn: (t) => ({
      x: 185 * Math.sin(0.20 * t),
      y: 135 * Math.sin(0.40 * t),
      alt: 260 + 120 * Math.sin(0.22 * t) + 30 * Math.sin(0.9 * t),
    }),
  },
  {
    id: 2,
    label: 'Multirrotor en hover (sintético)',
    sensor: 'ADS-B',
    fn: (t) => ({
      x: 320 + 2.5 * Math.sin(0.35 * t),
      y: -420 + 2 * Math.cos(0.29 * t),
      alt: 180 + 110 * Math.sin(0.3 * t) + 25 * Math.sin(2.2 * t),
    }),
  },
  {
    id: 3,
    label: 'UAS de largo alcance a 3000 ft (sintético)',
    sensor: 'MLAT',
    fn: (t) => {
      // Deriva lenta + zigzag cerrado: el patrón errático típico de un UAS
      // de largo alcance, no un círculo limpio de aeronave tripulada.
      return {
        x: 240 * Math.sin(0.10 * t) + 70 * Math.sin(0.24 * t),
        y: 210 * Math.cos(0.11 * t) + 55 * Math.cos(0.29 * t),
        alt: 3000 + 240 * Math.sin(0.26 * t),
      };
    },
  },
  {
    id: 6,
    label: 'Dron suplantando A320 (sintético)',
    sensor: 'ADS-B',
    callsign: 'IBE3174',
    reg: 'EC-NXF',
    type: 'A320',
    desc: 'AIRBUS A320',
    category: 'A3',
    addrType: 'adsb_other',
    fn: (t) => ({
      x: -260 + 180 * Math.cos(0.22 * t),
      y: 240 + 180 * Math.sin(0.22 * t),
      alt: 330 + 80 * Math.sin(0.35 * t),
    }),
  },
  {
    id: 4,
    label: 'Ala fija tripulada (control)',
    sensor: 'ADS-B',
    callsign: 'DEMO1',
    reg: 'EC-DEM',
    type: 'C172',
    desc: 'Cessna 172',
    category: 'A1',
    // Órbita amplia y limpia: 115 kt con 2,1°/s de giro. Es el patrón de
    // entrenamiento de un C172 y sirve de control negativo estable (no se aleja
    // del escenario ni genera maniobras que el motor pudiera confundir con UAS).
    fn: (t) => ({
      x: -260 + 1600 * Math.cos(0.037 * t),
      y: 240 + 1600 * Math.sin(0.037 * t),
      alt: 3400 + 40 * Math.sin(0.02 * t),
    }),
  },
  {
    id: 5,
    label: 'Helicóptero (control)',
    sensor: 'ADS-B',
    callsign: 'DEMO2',
    reg: 'EC-HLC',
    type: 'EC35',
    desc: 'Airbus H135',
    category: 'A7',
    fn: (t) => {
      const ang = 0.05 * t;
      return { x: Math.cos(ang) * 800, y: Math.sin(ang) * 800, alt: 900 + 60 * Math.sin(0.3 * t) };
    },
  },
];

function demoAircraft(lat, lon, groundElevFt, now, radiusKm = 20) {
  // El escenario es local: se mantiene la escala métrica original (~2 km) para
  // no alterar la física de las maniobras. El cliente ajusta el radar a 4 km.
  const k = 1;
  const t = (now - demoState.t0) / 1000;
  const dLat = (m) => m / 111320;
  const dLon = (m) => m / (111320 * Math.cos((lat * Math.PI) / 180));
  const out = [];

  for (const path of DEMO_PATHS) {
    const p = path.fn(t);
    const p2 = path.fn(t + 0.5 / k);
    const dx = p2.x - p.x;
    const dy = p2.y - p.y;
    const speedMs = Math.hypot(dx, dy) / (0.5 / k);
    const track = ((Math.atan2(dx, dy) * 180) / Math.PI + 360) % 360;
    const vrate = ((p2.alt - p.alt) / (0.5 / k)) * 60;
    const altAbs = groundElevFt + p.alt;

    out.push({
      hex: `demo${String(path.id).padStart(2, '0')}`,
      callsign: path.callsign || null,
      reg: path.reg || null,
      type: path.type || null,
      desc: path.desc || null,
      category: path.category || null,
      addrType: path.addrType || 'adsb_icao',
      lat: lat + dLat(p.y * k),
      lon: lon + dLon(p.x * k),
      altFt: altAbs,
      altBaroFt: altAbs,
      altGeomFt: altAbs,
      onGround: false,
      gsKt: +(speedMs * 1.943844).toFixed(1),
      track: +track.toFixed(1),
      vrateFpm: Math.round(vrate),
      roll: 0,
      trackRate: 0,
      squawk: null,
      emergency: null,
      sensor: path.sensor,
      mlatOnly: path.sensor === 'MLAT',
      flarm: false,
      rssi: null,
      seenSec: 0.2,
      source: 'demo',
      sources: ['demo'],
      demo: true,
      demoLabel: path.label,
    });
  }
  return out;
}

/**
 * Precalienta el historial del escenario sintético.
 *
 * El motor necesita ~20 muestras (unos 80 s) para medir giros, reversiones y
 * aceleraciones con robustez. Sin esto, al abrir el modo demostración los
 * drones aparecerían como "medio" durante el primer minuto y media, dando la
 * impresión de que el detector no funciona. Se reconstruyen 88 s de pasado con
 * la misma función de trayectoria, de modo que la demo es representativa desde
 * el primer barrido.
 */
function backfillDemo(store, lat, lon, groundElevFt, now) {
  const STEP_MS = 4000;
  const STEPS = 22;
  for (const path of DEMO_PATHS) {
    const hex = `demo${String(path.id).padStart(2, '0')}`;
    const existing = store.get(hex);
    if (existing && existing.samples.length >= STEPS) continue;
    for (let i = STEPS; i >= 1; i--) {
      const ts = now - i * STEP_MS;
      const batch = demoAircraft(lat, lon, groundElevFt, ts);
      const a = batch.find((x) => x.hex === hex);
      if (a) store.observe(a, ts);
    }
  }
}

/* ------------------------------ API ------------------------------ */

// Prioridad de presentación: riesgo cinemático, con la suplantación de
// identidad como eje independiente y ponderado (nunca sustituye al movimiento).
function priority(c) {
  const spoof = c.analysis.spoof ? c.analysis.spoof.score : 0;
  return Math.max(c.analysis.score, spoof * 0.85);
}


async function handleApi(req, res, url) {
  const p = url.pathname;

  if (p === '/api/health') {
    return json(res, 200, {
      ok: true,
      now: Date.now(),
      tracks: store.size(),
      sources: SOURCE_DEFS.map((s) => s.id),
      openskyCredentials: Boolean(process.env.OPENSKY_CLIENT_ID && process.env.OPENSKY_CLIENT_SECRET),
    });
  }

  if (p === '/api/scan') {
    const lat = Number(url.searchParams.get('lat'));
    const lon = Number(url.searchParams.get('lon'));
    const radiusKm = Math.min(250, Math.max(5, Number(url.searchParams.get('radius') || 40)));
    const demo = url.searchParams.get('demo') === '1';
    const ceiling = Math.min(15000, Math.max(400, Number(url.searchParams.get('ceiling') || 5000)));
    const cfg = { ...store.cfg, ceilingFt: ceiling };
    const enabled = (url.searchParams.get('sources') || 'opensky,adsbfi,adsblol,airplaneslive').split(',').filter(Boolean);
    if (!Number.isFinite(lat) || !Number.isFinite(lon)) return json(res, 400, { error: 'lat/lon requeridos' });

    const groundElevFt = await getElevation(lat, lon);
    const t0 = Date.now();

    let payload;
    if (demo) {
      backfillDemo(store, lat, lon, groundElevFt, Date.now());
      payload = {
        now: Date.now(),
        center: { lat, lon },
        radiusKm,
        sources: [{ id: 'demo', label: 'Escenario sintético', status: 'ok', count: 5, latencyMs: 0 }],
        aircraft: demoAircraft(lat, lon, groundElevFt, Date.now(), radiusKm),
      };
    } else {
      payload = await scan(lat, lon, radiusKm, enabled);
    }

    const contacts = payload.aircraft.map((a) => {
      const track = store.observe(a);
      track.groundElevFt = groundElevFt;
      const analysis = analyzeTrack(track, cfg, groundElevFt);
      analysis.spoof = assessSpoof(track, analysis);
      // Cuando la contradicción identidad/movimiento es sólida, la etiqueta de
      // perfil debe decirlo: es más útil para el operador que "ala fija".
      if (analysis.spoof.score >= 35) analysis.profile = 'UAS con identidad suplantada';
      const distM = haversineM(lat, lon, a.lat, a.lon);
      const brg = bearingDeg(lat, lon, a.lat, a.lon);
      return {
        hex: a.hex,
        callsign: a.callsign,
        reg: a.reg,
        type: a.type,
        desc: a.desc,
        category: a.category,
        lat: a.lat,
        lon: a.lon,
        altFt: a.altFt,
        altAglFt: a.altFt != null ? Math.round(a.altFt - groundElevFt) : null,
        gsKt: a.gsKt,
        track: a.track,
        vrateFpm: a.vrateFpm,
        roll: a.roll,
        sensor: a.sensor,
        squawk: a.squawk,
        emergency: a.emergency,
        source: a.source,
        sources: a.sources || [a.source],
        addrType: a.addrType || null,
        demo: !!a.demo,
        demoLabel: a.demoLabel || null,
        distM: Math.round(distM),
        bearing: +brg.toFixed(1),
        analysis,
        trail: track.samples.slice(-40).map((s) => [s.lat, s.lon, s.alt]),
      };
    });

    store.prune();
    contacts.sort((a, b) => priority(b) - priority(a) || a.distM - b.distM);

    return json(res, 200, {
      now: Date.now(),
      center: payload.center,
      radiusKm,
      groundElevFt: Math.round(groundElevFt),
      sources: payload.sources,
      demo,
      effectiveRadiusKm: demo ? 4 : radiusKm,
      elapsedMs: Date.now() - t0,
      counts: {
        total: contacts.length,
        critical: contacts.filter((c) => c.analysis.level === 'crítico').length,
        spoof: contacts.filter((c) => c.analysis.spoof && c.analysis.spoof.score >= 35).length,
        high: contacts.filter((c) => c.analysis.level === 'alto').length,
        medium: contacts.filter((c) => c.analysis.level === 'medio').length,
      },
      tracksKnown: store.size(),
      contacts,
    });
  }

  if (p === '/api/track') {
    const hex = url.searchParams.get('hex');
    const t = store.get(hex);
    if (!t) return json(res, 404, { error: 'pista no encontrada' });
    return json(res, 200, { hex, samples: t.samples, meta: t.meta, analysis: analyzeTrack(t, store.cfg, t.groundElevFt ?? null) });
  }

  if (p === '/api/reset' && req.method === 'POST') {
    store.reset();
    return json(res, 200, { ok: true });
  }

  return json(res, 404, { error: 'endpoint desconocido' });
}

/* --------------------------- estáticos --------------------------- */

function serveStatic(req, res, url) {
  let rel = decodeURIComponent(url.pathname);
  if (rel === '/' || rel === '') rel = '/index.html';
  const file = path.join(ROOT, path.normalize(rel).replace(/^(\.\.[/\\])+/, ''));
  if (!file.startsWith(ROOT)) {
    res.writeHead(403);
    return res.end('forbidden');
  }
  fs.readFile(file, (err, buf) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end('404');
    }
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(file)] || 'application/octet-stream',
      'Cache-Control': 'no-cache',
    });
    res.end(buf);
  });
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  if (req.method === 'OPTIONS') {
    res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': '*' });
    return res.end();
  }
  if (url.pathname.startsWith('/api/')) {
    handleApi(req, res, url).catch((e) => json(res, 500, { error: e.message }));
    return;
  }
  serveStatic(req, res, url);
});

server.listen(PORT, () => {
  console.log(`SkyWolf escuchando en http://localhost:${PORT}`);
});
