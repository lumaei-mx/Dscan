/* SkyWolf — escáner cinemático de UAS
 * Frontend sin frameworks. El backend (Node) agrega OpenSky y redes abiertas
 * de ADS-B/Mode-S; aquí se pinta el radar, el mapa y el análisis.
 */
'use strict';

/* ------------------------------------------------------------------ */
/* Configuración                                                       */
/* ------------------------------------------------------------------ */

const DEFAULTS = {
  radius: 40,
  threshold: 45,
  ceiling: 5000,
  interval: 4,
  sound: true,
  follow: true,
  showAll: true,
  sources: { opensky: true, adsbfi: true, adsblol: true, airplaneslive: true },
  lat: null,
  lon: null,
};

const SOURCE_LABELS = {
  opensky: 'OpenSky Network',
  adsbfi: 'adsb.fi (open data)',
  adsblol: 'adsb.lol',
  airplaneslive: 'airplanes.live',
};

const LEVEL_COLORS = {
  'crítico': '#ef4444',
  alto: '#f59e0b',
  medio: '#22d3ee',
  bajo: '#64748b',
  descartado: '#475569',
  'sin-datos': '#334155',
};

const LEVEL_RANK = { 'crítico': 5, alto: 4, medio: 3, bajo: 2, descartado: 1, 'sin-datos': 0 };

const loadCfg = () => {
  try {
    const raw = JSON.parse(localStorage.getItem('skywolf.cfg') || '{}');
    return { ...DEFAULTS, ...raw, sources: { ...DEFAULTS.sources, ...(raw.sources || {}) } };
  } catch (_) {
    return { ...DEFAULTS };
  }
};

const state = {
  cfg: loadCfg(),
  center: null,
  groundElevFt: 0,
  contacts: [],
  selectedHex: null,
  scanning: false,
  demo: false,
  timer: null,
  busy: false,
  lastScanAt: null,
  lastElapsed: null,
  alerts: [],
  scoreHistory: new Map(),
  alertedAt: new Map(),
  filter: 'all',
  view: 'radar',
  sources: [],
  sweep: 0,
  map: null,
  mapMarkers: new Map(),
  mapCircle: null,
  mapCenterMarker: null,
  mapTrails: new Map(),
  mapReady: false,
};

const $ = (sel) => document.querySelector(sel);

// En modo demostración el escenario es local (4 km) y el radar se ajusta.
const rangeKm = () => (state.demo ? 2 : state.cfg.radius);
const $$ = (sel) => [...document.querySelectorAll(sel)];

/* ------------------------------------------------------------------ */
/* Utilidades                                                          */
/* ------------------------------------------------------------------ */

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const fmt = (n, d = 0) => (n == null || !Number.isFinite(n) ? '—' : n.toFixed(d));
const fmtInt = (n) => (n == null || !Number.isFinite(n) ? '—' : Math.round(n).toLocaleString('es-ES'));

function fmtDist(m) {
  if (m == null) return '—';
  return m < 1000 ? `${Math.round(m)} m` : `${(m / 1000).toFixed(m < 10000 ? 2 : 1)} km`;
}

function fmtAlt(ft) {
  if (ft == null) return '—';
  return ft >= 1000 ? `${(ft / 1000).toFixed(ft < 10000 ? 2 : 1)}k ft` : `${Math.round(ft)} ft`;
}

function fmtClock(ts) {
  return new Date(ts).toLocaleTimeString('es-ES', { hour12: false });
}

function saveCfg() {
  localStorage.setItem('skywolf.cfg', JSON.stringify(state.cfg));
}

function toast(title, desc, critical = true) {
  const el = document.createElement('div');
  el.className = 'toast';
  if (!critical) el.style.borderColor = 'rgba(34,211,238,.45)';
  el.innerHTML = `<div class="t-icon">${critical ? '⚠' : 'ℹ'}</div><div><div class="t-title">${title}</div><div class="t-desc">${desc}</div></div>`;
  $('#toasts').appendChild(el);
  setTimeout(() => {
    el.style.transition = 'opacity .3s, transform .3s';
    el.style.opacity = '0';
    el.style.transform = 'translateX(20px)';
    setTimeout(() => el.remove(), 320);
  }, 5200);
}

/* Audio: dos tonos cortos, sin ficheros externos */
let audioCtx = null;
function beep(critical) {
  if (!state.cfg.sound) return;
  try {
    audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
    if (audioCtx.state === 'suspended') audioCtx.resume();
    const now = audioCtx.currentTime;
    const seq = critical ? [880, 1180, 880] : [720, 960];
    seq.forEach((f, i) => {
      const o = audioCtx.createOscillator();
      const g = audioCtx.createGain();
      o.type = 'sine';
      o.frequency.value = f;
      g.gain.setValueAtTime(0, now + i * 0.13);
      g.gain.linearRampToValueAtTime(0.09, now + i * 0.13 + 0.012);
      g.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.13 + 0.11);
      o.connect(g).connect(audioCtx.destination);
      o.start(now + i * 0.13);
      o.stop(now + i * 0.13 + 0.13);
    });
  } catch (_) { /* audio no disponible */ }
}

/* ------------------------------------------------------------------ */
/* Geolocalización                                                     */
/* ------------------------------------------------------------------ */

function setCenter(lat, lon, origin) {
  state.center = { lat, lon };
  state.cfg.lat = lat;
  state.cfg.lon = lon;
  saveCfg();
  $('#locText').textContent = `${lat.toFixed(4)}, ${lon.toFixed(4)}`;
  $('#chipLocation').title = `Centro del escáner (${origin})`;
  $('#chipLocation').classList.add('live');
  $('#sbCoords').textContent = `${lat.toFixed(4)} / ${lon.toFixed(4)}`;
  if (state.map) {
    state.map.setView([lat, lon], state.map.getZoom() || zoomForRadius(rangeKm()));
    if (state.mapCenterMarker) state.mapCenterMarker.setLatLng([lat, lon]);
    if (state.mapCircle) state.mapCircle.setLatLng([lat, lon]);
  }
  drawRadar();
}

function requestLocation() {
  return new Promise((resolve) => {
    if (!navigator.geolocation) {
      resolve(null);
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => resolve({ lat: pos.coords.latitude, lon: pos.coords.longitude, acc: pos.coords.accuracy }),
      (err) => resolve({ error: err }),
      { enableHighAccuracy: true, timeout: 12000, maximumAge: 60000 }
    );
  });
}

async function initLocation() {
  if (state.cfg.lat != null && state.cfg.lon != null) {
    setCenter(state.cfg.lat, state.cfg.lon, 'guardada');
    return true;
  }
  const r = await requestLocation();
  if (r && r.lat != null) {
    setCenter(r.lat, r.lon, `GPS ±${Math.round(r.acc)} m`);
    return true;
  }
  // Sin permiso: posición por defecto para no dejar la app vacía.
  setCenter(40.4168, -3.7038, 'por defecto · Madrid');
  $('#chipLocation').classList.remove('live');
  toast('Geolocalización no disponible', 'Usando posición por defecto. Puedes fijar tus coordenadas en Ajustes.', false);
  return false;
}

function watchPosition() {
  if (!navigator.geolocation) return;
  navigator.geolocation.watchPosition(
    (pos) => {
      if (!state.cfg.follow || !state.center) return;
      const d = haversineM(state.center.lat, state.center.lon, pos.coords.latitude, pos.coords.longitude);
      if (d > 300) setCenter(pos.coords.latitude, pos.coords.longitude, `GPS ±${Math.round(pos.coords.accuracy)} m`);
    },
    () => {},
    { enableHighAccuracy: true, maximumAge: 30000 }
  );
}

function haversineM(lat1, lon1, lat2, lon2) {
  const R = 6371000;
  const rad = (d) => (d * Math.PI) / 180;
  const dLat = rad(lat2 - lat1);
  const dLon = rad(lon2 - lon1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(rad(lat1)) * Math.cos(rad(lat2)) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(a)));
}

/* ------------------------------------------------------------------ */
/* Escaneo                                                             */
/* ------------------------------------------------------------------ */

async function scanOnce() {
  if (!state.center || state.busy) return;
  state.busy = true;
  const enabled = Object.entries(state.cfg.sources).filter(([, v]) => v).map(([k]) => k);
  if (!state.demo && enabled.length === 0) {
    toast('Sin fuentes activas', 'Activa al menos una fuente en Ajustes.', false);
    state.busy = false;
    stopScan();
    return;
  }
  const qs = new URLSearchParams({
    lat: state.center.lat.toFixed(5),
    lon: state.center.lon.toFixed(5),
    radius: String(state.cfg.radius),
    ceiling: String(state.cfg.ceiling),
    sources: enabled.join(','),
  });
  if (state.demo) qs.set('demo', '1');

  try {
    const res = await fetch(`/api/scan?${qs}`, { cache: 'no-store' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    state.contacts = data.contacts || [];
    state.sources = data.sources || [];
    state.groundElevFt = data.groundElevFt || 0;
    state.lastScanAt = Date.now();
    state.lastElapsed = data.elapsedMs;
    $('#chipStatus').className = 'chip live';
    $('#statusText').textContent = state.demo ? 'Escaneo sintético' : 'Escaneando';
    $('#sbLatency').textContent = `${data.elapsedMs} ms · ${data.contacts.length} contactos`;
    $('#trackCount').textContent = data.tracksKnown ?? data.contacts.length;
    processAlerts();
    renderAll();
  } catch (e) {
    $('#chipStatus').className = 'chip err';
    $('#statusText').textContent = 'Error de red';
    $('#sbLatency').textContent = e.message;
    if (!state.lastScanAt) toast('No se pudo consultar el servidor', e.message, false);
  } finally {
    state.busy = false;
    updateStatusbar();
  }
}

function processAlerts() {
  const now = Date.now();
  for (const c of state.contacts) {
    const a = c.analysis;
    const key = c.hex;
    const last = state.alertedAt.get(key) || 0;
    if (a.score >= state.cfg.threshold && now - last > 90000) {
      state.alertedAt.set(key, now);
      const critical = a.level === 'crítico';
      state.alerts.unshift({
        t: now,
        hex: c.hex,
        title: `${a.profile} · ${a.score}/100`,
        desc: `${c.demoLabel || c.callsign || c.reg || c.hex} · ${fmtDist(c.distM)} · ${fmtAlt(c.altFt)} · ${a.evidences[0]?.text || ''}`,
        critical,
      });
      if (state.alerts.length > 120) state.alerts.pop();
      beep(critical);
      toast(
        critical ? 'Contacto crítico' : 'Contacto anómalo',
        `${c.demoLabel || c.callsign || c.hex} · ${a.profile} · ${a.score}/100 · ${fmtDist(c.distM)}`,
        critical
      );
    }
  }
  const badge = $('#alertBadge');
  badge.textContent = state.alerts.length ? `(${state.alerts.length})` : '';
  badge.style.color = 'var(--amber)';
}

function startScan() {
  if (state.scanning) return;
  state.scanning = true;
  $('#scanLabel').textContent = 'Pausar';
  $('#btnScan').classList.remove('primary');
  $('#btnScan').classList.add('danger');
  $('#chipStatus').className = 'chip warn';
  $('#statusText').textContent = 'Iniciando…';
  scanOnce();
  state.timer = setInterval(scanOnce, state.cfg.interval * 1000);
}

function stopScan() {
  state.scanning = false;
  clearInterval(state.timer);
  state.timer = null;
  $('#scanLabel').textContent = 'Iniciar escaneo';
  $('#btnScan').classList.add('primary');
  $('#btnScan').classList.remove('danger');
  $('#chipStatus').className = 'chip';
  $('#statusText').textContent = 'En pausa';
}

/* ------------------------------------------------------------------ */
/* Render: estadísticas, lista, fuentes, alertas                        */
/* ------------------------------------------------------------------ */

function visibleContacts() {
  let list = state.contacts;
  if (!state.cfg.showAll) list = list.filter((c) => c.analysis.level !== 'descartado');
  if (state.filter === 'critical') list = list.filter((c) => c.analysis.level === 'crítico');
  else if (state.filter === 'high') list = list.filter((c) => ['crítico', 'alto'].includes(c.analysis.level));
  else if (state.filter === 'uas') list = list.filter((c) => /FPV|Multirrotor|UAS/i.test(c.analysis.profile));
  else if (state.filter === 'spoof') list = list.filter((c) => (c.analysis.spoof?.score || 0) >= 35);
  return list;
}

function renderAll() {
  renderStats();
  const spoofN = state.contacts.filter((c) => (c.analysis.spoof?.score || 0) >= 35).length;
  const fb = document.querySelector('.filter-btn[data-filter="spoof"]');
  if (fb) fb.textContent = spoofN ? `Suplantación (${spoofN})` : 'Suplantación';
  renderList();
  renderSources();
  renderAlerts();
  renderMap();
  drawRadar();
  updateStatusbar();
}

function renderStats() {
  const total = state.contacts.length;
  const crit = state.contacts.filter((c) => c.analysis.level === 'crítico').length;
  const high = state.contacts.filter((c) => c.analysis.level === 'alto').length;
  const ok = state.sources.filter((s) => s.status === 'ok').length;
  $('#statTotal').textContent = total;
  $('#statCritical').textContent = crit;
  $('#statHigh').textContent = high;
  $('#statSources').textContent = ok;
}

function scoreStyle(score, level) {
  const color = LEVEL_COLORS[level] || '#64748b';
  return `color:${color};border-color:${color}55;background:${color}12;box-shadow:inset 0 0 18px ${color}18`;
}

function renderList() {
  const list = visibleContacts();
  const box = $('#contactList');
  if (!list.length) {
    box.innerHTML = `<div class="empty">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/><path d="M12 12 18 7"/></svg>
      <div>${state.contacts.length ? 'Ningún contacto cumple el filtro actual.' : 'Sin datos todavía.<br/>Pulsa <b>Iniciar escaneo</b> para barrer el espacio aéreo.'}</div>
    </div>`;
    return;
  }
  box.innerHTML = list
    .map((c) => {
      const a = c.analysis;
      const color = LEVEL_COLORS[a.level] || '#64748b';
      const id = c.demoLabel || c.callsign || c.reg || c.hex;
      const sp = c.analysis.spoof || { score: 0 };
      const tags = [c.type, c.sensor].filter(Boolean).map((t) => `<span class="type-tag">${t}</span>`).join('') +
        (sp.score >= 35 ? `<span class="type-tag spoof-tag" title="La identidad declarada contradice el movimiento observado">SUPLANTACIÓN ${sp.score}</span>` : '');
      return `<div class="contact ${c.hex === state.selectedHex ? 'selected' : ''}" data-hex="${c.hex}">
        <div class="contact-score" style="${scoreStyle(a.score, a.level)}">${a.score}<small>${a.level === 'sin-datos' ? 'N/D' : a.level.toUpperCase().slice(0, 4)}</small></div>
        <div class="contact-main">
          <div class="contact-id">${id} ${tags}</div>
          <div class="contact-sub"><b>${fmtDist(c.distM)}</b><span>${fmtInt(c.bearing)}°</span><span>${fmtAlt(c.altFt)}</span><span>${fmt(c.gsKt)} kt</span></div>
          <div class="contact-profile">${a.profile} · conf. ${a.confidence}%</div>
        </div>
        <div class="contact-right">
          <div class="contact-dist">${c.altAglFt != null ? fmtInt(c.altAglFt) + ' ft AGL' : ''}</div>
          <div class="contact-level" style="color:${color}">${a.level}</div>
        </div>
      </div>`;
    })
    .join('');

  box.querySelectorAll('.contact').forEach((el) => {
    el.addEventListener('click', () => selectContact(el.dataset.hex));
  });
}

function renderSources() {
  const box = $('#sourceList');
  if (!state.sources.length) {
    box.innerHTML = '<div class="empty"><div>Sin datos de fuentes.<br/>Inicia un escaneo.</div></div>';
    return;
  }
  box.innerHTML = state.sources
    .map(
      (s) => `<div class="src-row">
        <span class="src-status ${s.status}"></span>
        <span class="src-name">${s.label || SOURCE_LABELS[s.id] || s.id}</span>
        <span class="src-meta">${s.status === 'ok' ? `${s.count} contactos · ${s.latencyMs} ms` : s.error || 'error'}</span>
      </div>`
    )
    .join('') +
    `<div style="padding:12px;font-size:10.5px;line-height:1.5;color:var(--text-faint)">
      OpenSky aporta estado ADS-B/ASTERIX/MLAT; las redes abiertas tipo dump1090 añaden multilateración y cobertura local.
      Los contactos se deduplican por dirección ICAO de 24 bits.
    </div>`;
}

function renderAlerts() {
  const box = $('#alertList');
  if (!state.alerts.length) {
    box.innerHTML = '<div class="empty"><div>No hay alertas registradas.<br/>Las detecciones que superen el umbral aparecerán aquí.</div></div>';
    return;
  }
  box.innerHTML = state.alerts
    .map(
      (a) => `<div class="alert-item ${a.critical ? 'critical' : ''}" data-hex="${a.hex}">
        <div class="alert-time">${fmtClock(a.t)}</div>
        <div class="alert-body">
          <div class="alert-title">${a.title}</div>
          <div class="alert-desc">${a.desc}</div>
        </div>
      </div>`
    )
    .join('');
  box.querySelectorAll('.alert-item').forEach((el) => el.addEventListener('click', () => selectContact(el.dataset.hex)));
}

function updateStatusbar() {
  $('#sbRadius').textContent = `${rangeKm()} km${state.demo ? ' · demo' : ''}`;
  $('#sbCeiling').textContent = `${fmtInt(state.cfg.ceiling)} ft`;
  $('#sbLast').textContent = state.lastScanAt ? fmtClock(state.lastScanAt) : '—';
  $('#radarRangeLabel').textContent = `Radio ${rangeKm()} km${state.demo ? ' · demo' : ''}`;
}

/* ------------------------------------------------------------------ */
/* Radar PPI                                                           */
/* ------------------------------------------------------------------ */

const canvas = $('#radarCanvas');
const ctx = canvas.getContext('2d');
let radarW = 0;
let radarH = 0;

function resizeRadar() {
  const rect = canvas.getBoundingClientRect();
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  radarW = rect.width;
  radarH = rect.height;
  canvas.width = Math.max(1, Math.round(rect.width * dpr));
  canvas.height = Math.max(1, Math.round(rect.height * dpr));
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
}

function project(lat, lon) {
  const c = state.center;
  if (!c) return null;
  const rangeM = rangeKm() * 1000;
  const dLat = lat - c.lat;
  const dLon = lon - c.lon;
  const north = dLat * 111320;
  const east = dLon * 111320 * Math.cos((c.lat * Math.PI) / 180);
  const R = Math.min(radarW, radarH) / 2 - 30;
  return {
    x: radarW / 2 + (east / rangeM) * R,
    y: radarH / 2 - (north / rangeM) * R,
    distM: Math.hypot(north, east),
    R,
  };
}

function drawRadar() {
  if (!radarW || !radarH) return;
  const w = radarW;
  const h = radarH;
  const cx = w / 2;
  const cy = h / 2;
  const R = Math.min(w, h) / 2 - 30;

  ctx.clearRect(0, 0, w, h);

  // Fondo
  const bg = ctx.createRadialGradient(cx, cy, 0, cx, cy, R * 1.05);
  bg.addColorStop(0, 'rgba(12,32,42,0.55)');
  bg.addColorStop(1, 'rgba(4,8,12,0.2)');
  ctx.fillStyle = bg;
  ctx.beginPath();
  ctx.arc(cx, cy, R, 0, Math.PI * 2);
  ctx.fill();

  // Anillos
  ctx.strokeStyle = 'rgba(34,211,238,0.13)';
  ctx.lineWidth = 1;
  for (let i = 1; i <= 4; i++) {
    ctx.beginPath();
    ctx.arc(cx, cy, (R * i) / 4, 0, Math.PI * 2);
    ctx.stroke();
  }
  // Cruz
  ctx.strokeStyle = 'rgba(34,211,238,0.10)';
  ctx.beginPath();
  ctx.moveTo(cx - R, cy); ctx.lineTo(cx + R, cy);
  ctx.moveTo(cx, cy - R); ctx.lineTo(cx, cy + R);
  ctx.stroke();

  // Marcas de rumbo
  ctx.font = '9px ui-monospace, monospace';
  ctx.fillStyle = 'rgba(127,147,164,0.55)';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  for (let b = 0; b < 360; b += 15) {
    const a = (b - 90) * (Math.PI / 180);
    const inner = b % 45 === 0 ? R - 10 : R - 5;
    ctx.strokeStyle = b % 45 === 0 ? 'rgba(34,211,238,0.28)' : 'rgba(34,211,238,0.13)';
    ctx.beginPath();
    ctx.moveTo(cx + Math.cos(a) * inner, cy + Math.sin(a) * inner);
    ctx.lineTo(cx + Math.cos(a) * R, cy + Math.sin(a) * R);
    ctx.stroke();
    if (b % 45 === 0) {
      const lbl = b === 0 ? 'N' : b === 90 ? 'E' : b === 180 ? 'S' : b === 270 ? 'O' : String(b);
      ctx.fillStyle = b % 90 === 0 ? 'rgba(167,196,214,0.85)' : 'rgba(127,147,164,0.5)';
      ctx.fillText(lbl, cx + Math.cos(a) * (R - 20), cy + Math.sin(a) * (R - 20));
    }
  }

  // Etiquetas de distancia
  ctx.textAlign = 'left';
  ctx.fillStyle = 'rgba(127,147,164,0.4)';
  for (let i = 1; i <= 4; i++) {
    const km = (rangeKm() * i) / 4;
    ctx.fillText(`${km % 1 === 0 ? km : km.toFixed(1)} km`, cx + 4, cy - (R * i) / 4 + 2);
  }

  // Barrido
  const sweepA = (state.sweep * Math.PI) / 180;
  const grad = ctx.createConicGradient ? null : null;
  ctx.save();
  ctx.beginPath();
  ctx.arc(cx, cy, R, 0, Math.PI * 2);
  ctx.clip();
  const trail = 52 * (Math.PI / 180);
  for (let i = 0; i < 26; i++) {
    const a1 = sweepA - (trail * i) / 26;
    const a0 = sweepA - (trail * (i + 1)) / 26;
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    // a0 < a1 para que el arco se dibuje en el sentido corto (horario)
    ctx.arc(cx, cy, R, Math.min(a0, a1), Math.max(a0, a1));
    ctx.closePath();
    ctx.fillStyle = `rgba(34,211,238,${0.10 * (1 - i / 26)})`;
    ctx.fill();
  }
  ctx.strokeStyle = 'rgba(34,211,238,0.55)';
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  ctx.moveTo(cx, cy);
  ctx.lineTo(cx + Math.cos(sweepA) * R, cy + Math.sin(sweepA) * R);
  ctx.stroke();
  ctx.restore();

  // Estelas
  for (const c of state.contacts) {
    if (!c.trail || c.trail.length < 2) continue;
    const color = LEVEL_COLORS[c.analysis.level] || '#64748b';
    ctx.strokeStyle = color + '55';
    ctx.lineWidth = c.hex === state.selectedHex ? 1.8 : 1;
    ctx.beginPath();
    let started = false;
    for (const p of c.trail) {
      const pr = project(p[0], p[1]);
      if (!pr || pr.distM > rangeKm() * 1000) { started = false; continue; }
      if (!started) { ctx.moveTo(pr.x, pr.y); started = true; }
      else ctx.lineTo(pr.x, pr.y);
    }
    ctx.stroke();
  }

  // Contactos. Se dibujan TODOS los que caen dentro del radio: el operador debe
  // ver el tráfico de fondo aunque el motor lo haya descartado. Los descartados
  // van atenuados; sólo los relevantes llevan etiqueta.
  const inRange = state.contacts.filter((c) => {
    const pr = project(c.lat, c.lon);
    return pr && pr.distM <= rangeKm() * 1000;
  });
  const visible = visibleContacts().filter((c) => {
    const pr = project(c.lat, c.lon);
    return pr && pr.distM <= rangeKm() * 1000;
  });
  const labeled = new Set(visible.slice(0, 14).map((c) => c.hex));
  const placedLabels = [];
  if (state.selectedHex) labeled.add(state.selectedHex);

  for (const c of inRange) {
    const pr = project(c.lat, c.lon);
    if (!pr) continue;
    const a = c.analysis;
    const dim = a.level === 'descartado' || a.level === 'sin-datos';
    const color = LEVEL_COLORS[a.level] || '#64748b';
    const isSel = c.hex === state.selectedHex;
    const size = dim ? 2.1 : 3 + clamp(a.score / 22, 0.6, 3.4) + (isSel ? 1.6 : 0);
    ctx.globalAlpha = dim ? 0.55 : 1;

    // halo
    ctx.beginPath();
    ctx.arc(pr.x, pr.y, size + (dim ? 2.5 : 6), 0, Math.PI * 2);
    ctx.fillStyle = color + (dim ? '10' : '18');
    ctx.fill();

    // punto
    ctx.beginPath();
    ctx.arc(pr.x, pr.y, size, 0, Math.PI * 2);
    ctx.fillStyle = color;
    ctx.shadowColor = color;
    ctx.shadowBlur = a.score >= 45 ? 12 : 5;
    ctx.fill();
    ctx.shadowBlur = 0;

    if (isSel) {
      ctx.strokeStyle = '#e2f8ff';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.arc(pr.x, pr.y, size + 7, 0, Math.PI * 2);
      ctx.stroke();
    }

    if (labeled.has(c.hex)) {
      const label = c.demoLabel ? c.demoLabel.replace(' (sintético)', '') : c.callsign || c.reg || c.hex;
      const alt = c.altFt != null ? `${(c.altFt / 1000).toFixed(1)}k` : '';
      ctx.font = '9.5px ui-monospace, monospace';
      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';
      const text = `${label} ${alt}`.trim();
      const tw = ctx.measureText(text).width;
      // Evita solapes: prueba arriba-derecha, abajo-derecha, izquierda…
      const candidates = [
        [pr.x + size + 5, pr.y - size - 3],
        [pr.x + size + 5, pr.y + size + 7],
        [pr.x - tw - size - 7, pr.y - size - 3],
        [pr.x - tw - size - 7, pr.y + size + 7],
        [pr.x + size + 5, pr.y - size - 16],
      ];
      let lx = candidates[0][0];
      let ly = candidates[0][1];
      for (const [cx2, cy2] of candidates) {
        const box = { x: cx2 - 2, y: cy2 - 6, w: tw + 5, h: 12 };
        const hit = placedLabels.some(
          (b) => box.x < b.x + b.w && box.x + box.w > b.x && box.y < b.y + b.h && box.y + box.h > b.y
        );
        if (!hit) { lx = cx2; ly = cy2; break; }
      }
      placedLabels.push({ x: lx - 2, y: ly - 6, w: tw + 5, h: 12 });
      ctx.fillStyle = 'rgba(4,8,12,0.78)';
      ctx.fillRect(lx - 2, ly - 6, tw + 5, 12);
      ctx.fillStyle = isSel ? '#e2f8ff' : color + 'dd';
      ctx.fillText(text, lx, ly);
    }
    ctx.globalAlpha = 1;
  }

  // Centro (usuario)
  ctx.beginPath();
  ctx.arc(cx, cy, 4.5, 0, Math.PI * 2);
  ctx.fillStyle = '#22d3ee';
  ctx.shadowColor = '#22d3ee';
  ctx.shadowBlur = 14;
  ctx.fill();
  ctx.shadowBlur = 0;
  ctx.strokeStyle = 'rgba(34,211,238,0.5)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.arc(cx, cy, 11, 0, Math.PI * 2);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(cx, cy, 18 + 3 * Math.sin(performance.now() / 600), 0, Math.PI * 2);
  ctx.strokeStyle = 'rgba(34,211,238,0.16)';
  ctx.stroke();

  $('#radarSweepLabel').textContent = `Barrido ${Math.round(state.sweep)}°`;
}

let lastFrame = 0;
function radarLoop(ts) {
  const dt = lastFrame ? Math.min(100, ts - lastFrame) : 16;
  lastFrame = ts;
  state.sweep = (state.sweep + dt * 0.045) % 360;
  drawRadar();
  requestAnimationFrame(radarLoop);
}

canvas.addEventListener('click', (e) => {
  const rect = canvas.getBoundingClientRect();
  const mx = e.clientX - rect.left;
  const my = e.clientY - rect.top;
  let best = null;
  let bestD = 18;
  for (const c of state.contacts) {
    const pr = project(c.lat, c.lon);
    if (!pr) continue;
    const d = Math.hypot(pr.x - mx, pr.y - my);
    if (d < bestD) { bestD = d; best = c; }
  }
  if (best) selectContact(best.hex);
});

/* ------------------------------------------------------------------ */
/* Mapa                                                                */
/* ------------------------------------------------------------------ */

// Zoom que encuadra el radio de barrido con un margen del 25 %.
function zoomForRadius(km) {
  const z = Math.round(14 - Math.log2(Math.max(0.5, km) / 2));
  return clamp(z, 8, 15);
}

function initMap() {
  if (state.mapReady || typeof L === 'undefined') return;
  const c = state.center || { lat: 40.4168, lon: -3.7038 };
  state.map = L.map('map', { zoomControl: true, attributionControl: true, preferCanvas: true })
    .setView([c.lat, c.lon], zoomForRadius(rangeKm()));
  // Carto exige ahora clave de API para tiles servidos a terceros; Esri publica
  // el "Dark Gray Canvas" sin clave. Se añade la capa de referencia (etiquetas)
  // para conservar nombres de ciudades y carreteras.
  L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/{z}/{y}/{x}', {
    attribution: '&copy; Esri &copy; OpenStreetMap',
    maxZoom: 16,
  }).addTo(state.map);
  L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Reference/MapServer/tile/{z}/{y}/{x}', {
    maxZoom: 16,
    pane: 'overlayPane',
  }).addTo(state.map);

  state.mapCircle = L.circle([c.lat, c.lon], {
    radius: rangeKm() * 1000,
    color: '#22d3ee',
    weight: 1,
    opacity: 0.55,
    fillColor: '#22d3ee',
    fillOpacity: 0.035,
    dashArray: '4 6',
  }).addTo(state.map);

  state.mapCenterMarker = L.circleMarker([c.lat, c.lon], {
    radius: 6,
    color: '#22d3ee',
    weight: 2,
    fillColor: '#22d3ee',
    fillOpacity: 0.9,
  }).addTo(state.map).bindTooltip('Tu posición', { permanent: false });

  state.mapReady = true;
}

function renderMap() {
  if (state.view !== 'map') return;
  initMap();
  if (!state.map || !state.mapReady) return;

  if (state.mapCircle) state.mapCircle.setRadius(rangeKm() * 1000);

  const seen = new Set();
  for (const c of visibleContacts()) {
    seen.add(c.hex);
    const color = LEVEL_COLORS[c.analysis.level] || '#64748b';
    const isSel = c.hex === state.selectedHex;
    const size = 14 + Math.round(c.analysis.score / 8);
    const icon = L.divIcon({
      className: '',
      html: `<div style="width:${size}px;height:${size}px;border-radius:50%;background:${color}22;border:${isSel ? 2 : 1.4}px solid ${color};display:grid;place-items:center;box-shadow:0 0 12px ${color}66;font:600 9px ui-monospace,monospace;color:${color}">${c.analysis.score}</div>`,
      iconSize: [size, size],
      iconAnchor: [size / 2, size / 2],
    });
    let m = state.mapMarkers.get(c.hex);
    if (!m) {
      m = L.marker([c.lat, c.lon], { icon }).addTo(state.map);
      m.on('click', () => selectContact(c.hex));
      state.mapMarkers.set(c.hex, m);
    } else {
      m.setLatLng([c.lat, c.lon]);
      m.setIcon(icon);
    }
    m.bindTooltip(
      `<b>${c.demoLabel || c.callsign || c.reg || c.hex}</b><br/>${c.analysis.profile} · ${c.analysis.score}/100<br/>${fmtDist(c.distM)} · ${fmtAlt(c.altFt)}`,
      { direction: 'top', offset: [0, -6] }
    );

    const pts = (c.trail || []).map((p) => [p[0], p[1]]);
    let line = state.mapTrails.get(c.hex);
    if (!line) {
      line = L.polyline(pts, { color, weight: 1.4, opacity: 0.55 }).addTo(state.map);
      state.mapTrails.set(c.hex, line);
    } else {
      line.setLatLngs(pts);
      line.setStyle({ color });
    }
  }

  for (const [hex, m] of state.mapMarkers) {
    if (!seen.has(hex)) { state.map.removeLayer(m); state.mapMarkers.delete(hex); }
  }
  for (const [hex, l] of state.mapTrails) {
    if (!seen.has(hex)) { state.map.removeLayer(l); state.mapTrails.delete(hex); }
  }
}

/* ------------------------------------------------------------------ */
/* Detalle                                                             */
/* ------------------------------------------------------------------ */

function selectContact(hex) {
  state.selectedHex = hex;
  renderList();
  drawRadar();
  renderMap();
  openDrawer(hex);
}

function openDrawer(hex) {
  const c = state.contacts.find((x) => x.hex === hex);
  if (!c) return;
  const a = c.analysis;
  const color = LEVEL_COLORS[a.level] || '#64748b';

  $('#dTitle').textContent = c.demoLabel || c.callsign || c.reg || c.hex;
  $('#dSub').textContent = [c.hex, c.reg, c.type, c.sensor].filter(Boolean).join(' · ');

  const m = a.metrics || {};
  const metric = (k, v, unit = '') => `<div class="metric"><div class="metric-k">${k}</div><div class="metric-v">${v}${unit ? ` <span>${unit}</span>` : ''}</div></div>`;

  const evidences = (a.evidences || [])
    .map(
      (e) => `<div class="evidence ${e.pts < 0 ? 'neg' : ''}">
        <div class="ev-pts">${e.pts > 0 ? '+' : ''}${e.pts}</div>
        <div><div class="ev-text">${e.text}</div><div class="ev-tag">${e.tag}</div></div>
      </div>`
    )
    .join('') || '<div class="evidence"><div class="ev-text">Aún no hay suficientes muestras para un diagnóstico cinemático. Mantén el escaneo activo: el motor necesita al menos 4 posiciones encadenadas.</div></div>';

  $('#drawerBody').innerHTML = `
    <div class="score-hero">
      <div class="gauge"><canvas id="gaugeCanvas" width="164" height="164"></canvas><div class="gauge-val" style="color:${color}">${a.score}</div></div>
      <div class="score-meta">
        <div class="score-level" style="color:${color}">${a.level}</div>
        <div class="score-profile">${a.profile}</div>
        <div class="score-note">${a.samples} muestras · ${Math.round(a.spanSec)} s observados · confianza ${a.confidence}%<br/>Umbral de alerta: ${state.cfg.threshold}</div>
      </div>
    </div>

    <div class="sec-title">Cinemática</div>
    <div class="metrics-grid">
      ${metric('Giro máx.', fmt(m.maxTurnRate, 1), '°/s')}
      ${metric('Reversiones', fmtInt(m.reversals))}
      ${metric('Vel. media', fmt(m.medSpeedKt, 1), 'kt')}
      ${metric('Vel. máx.', fmt(m.maxSpeedKt, 1), 'kt')}
      ${metric('Aceleración', fmt(m.maxAccelKtS, 2), 'kt/s')}
      ${metric('Rég. vertical', fmtInt(m.maxVrateFpm), 'ft/min')}
      ${metric('Altitud mín.', fmtInt(m.altMinFt), 'ft')}
      ${metric('Altitud máx.', fmtInt(m.altMaxFt), 'ft')}
      ${metric('Sobre terreno', fmtInt(m.altAglFt), 'ft AGL')}
      ${metric('Rectitud', fmt(m.straightness, 2))}
      ${metric('Distancia', fmtDist(c.distM))}
      ${metric('Rumbo', fmtInt(c.bearing), '°')}
    </div>

    <div class="sec-title">Perfil de altitud</div>
    <div class="chart-box">
      <canvas id="altChart" width="760" height="220"></canvas>
      <div class="chart-legend"><span>— altitud (ft)</span><span id="altRangeTxt"></span></div>
    </div>

    <div class="sec-title">Evidencias (${a.evidences.length})</div>
    ${evidences}

    ${renderSpoofBlock(c, a)}

    <div class="sec-title">Identidad</div>
    <div class="metrics-grid">
      ${metric('ICAO', c.hex || '—')}
      ${metric('Indicativo', c.callsign || '—')}
      ${metric('Matrícula', c.reg || '—')}
      ${metric('Tipo', c.type || '—')}
      ${metric('Categoría', c.category || '—')}
      ${metric('Squawk', c.squawk || '—')}
    </div>
    <div class="id-note" style="margin-top:10px">
      <span>◈</span>
      <div>Estos datos se muestran sólo como referencia. <b>El motor ignora por completo la identidad</b> al calcular el riesgo: dos aeronaves con el mismo movimiento obtienen la misma puntuación, declare lo que declare su emisor.</div>
    </div>

    <div class="sec-title">Fuentes</div>
    <div style="font-family:var(--mono);font-size:10.5px;color:var(--text-dim);line-height:1.6">
      ${(c.sources || []).map((s) => SOURCE_LABELS[s] || s).join(' · ')}<br/>
      Sensor: ${c.sensor || '—'} · Vrate: ${fmtInt(c.vrateFpm)} ft/min · Roll: ${c.roll != null ? fmt(c.roll, 1) + '°' : '—'}
    </div>
  `;

  drawGauge(a.score, color);
  drawAltChart(c);
  $('#drawer').classList.add('open');
  document.body.classList.add('drawer-open');
  $('#drawer').setAttribute('aria-hidden', 'false');
}

function closeDrawer() {
  $('#drawer').classList.remove('open');
  document.body.classList.remove('drawer-open');
  $('#drawer').setAttribute('aria-hidden', 'true');
  state.selectedHex = null;
  renderList();
  drawRadar();
  renderMap();
}


/**
 * Bloque de suplantación: contrasta lo que el emisor declara con lo que el
 * movimiento demuestra. No es una prueba de dron por sí sola, sino una
 * contradicción objetiva entre dos conjuntos de datos del mismo contacto.
 */
function renderSpoofBlock(c, a) {
  const sp = a.spoof;
  if (!sp) return '';
  const d = sp.declared || {};
  const declaredBits = [
    c.callsign ? `indicativo ${c.callsign}` : null,
    c.type ? `tipo ${c.type}` : null,
    c.category ? `categoría ${c.category}` : null,
    c.reg ? `matrícula ${c.reg}` : null,
  ].filter(Boolean);

  const flags = (sp.flags || [])
    .filter((f) => f.pts > 0)
    .map((f) => `<div class="spoof-flag"><b>+${f.pts}</b><span>${f.text}</span></div>`)
    .join('');

  const observed = `observado: ${fmt(a.metrics?.medSpeedKt, 1)} kt medios · giro máx. ${fmt(a.metrics?.maxTurnRate, 1)}°/s · ${fmtInt(a.metrics?.altAglFt)} ft AGL`;

  return `
    <div class="sec-title">Suplantación de identidad</div>
    <div class="spoof-box">
      <div class="spoof-head">
        <div class="spoof-score">${sp.score}</div>
        <div class="spoof-level">${sp.level}</div>
      </div>
      <div class="spoof-declared">${declaredBits.length ? 'declara: ' + declaredBits.join(' · ') : 'sin identidad declarada'}<br/>${observed}</div>
      ${flags || '<div class="spoof-flag"><span>La identidad declarada es coherente con el movimiento observado.</span></div>'}
    </div>
  `;
}

function drawGauge(score, color) {
  const cv = $('#gaugeCanvas');
  if (!cv) return;
  const g = cv.getContext('2d');
  const w = cv.width;
  const h = cv.height;
  const cx = w / 2;
  const cy = h / 2;
  const r = w / 2 - 12;
  g.clearRect(0, 0, w, h);
  g.lineWidth = 11;
  g.lineCap = 'round';
  g.strokeStyle = 'rgba(255,255,255,0.06)';
  g.beginPath();
  g.arc(cx, cy, r, Math.PI * 0.75, Math.PI * 2.25);
  g.stroke();
  const end = Math.PI * 0.75 + (Math.PI * 1.5 * clamp(score, 0, 100)) / 100;
  const grad = g.createLinearGradient(0, 0, w, h);
  grad.addColorStop(0, color);
  grad.addColorStop(1, color + '99');
  g.strokeStyle = grad;
  g.beginPath();
  g.arc(cx, cy, r, Math.PI * 0.75, end);
  g.stroke();
}

function drawAltChart(c) {
  const cv = $('#altChart');
  if (!cv) return;
  const g = cv.getContext('2d');
  const w = cv.width;
  const h = cv.height;
  g.clearRect(0, 0, w, h);
  const pts = (c.trail || []).map((p) => p[2]).filter((v) => typeof v === 'number');
  if (pts.length < 2) {
    g.fillStyle = 'rgba(127,147,164,0.5)';
    g.font = '16px ui-monospace, monospace';
    g.fillText('Sin historial de altitud', 20, h / 2);
    return;
  }
  const min = Math.min(...pts);
  const max = Math.max(...pts);
  const pad = 16;
  const span = Math.max(120, max - min);
  const x = (i) => pad + (i / (pts.length - 1)) * (w - pad * 2);
  const y = (v) => h - pad - ((v - min) / span) * (h - pad * 2);

  g.strokeStyle = 'rgba(255,255,255,0.05)';
  g.lineWidth = 1;
  for (let i = 0; i <= 3; i++) {
    const yy = pad + (i / 3) * (h - pad * 2);
    g.beginPath(); g.moveTo(pad, yy); g.lineTo(w - pad, yy); g.stroke();
  }

  g.beginPath();
  g.moveTo(x(0), y(pts[0]));
  pts.forEach((v, i) => g.lineTo(x(i), y(v)));
  g.lineTo(x(pts.length - 1), h - pad);
  g.lineTo(x(0), h - pad);
  g.closePath();
  const fill = g.createLinearGradient(0, 0, 0, h);
  fill.addColorStop(0, 'rgba(34,211,238,0.28)');
  fill.addColorStop(1, 'rgba(34,211,238,0.01)');
  g.fillStyle = fill;
  g.fill();

  g.beginPath();
  pts.forEach((v, i) => (i ? g.lineTo(x(i), y(v)) : g.moveTo(x(i), y(v))));
  g.strokeStyle = '#22d3ee';
  g.lineWidth = 2;
  g.stroke();

  g.fillStyle = 'rgba(167,196,214,0.75)';
  g.font = '13px ui-monospace, monospace';
  g.fillText(`${Math.round(max)} ft`, pad, 14);
  g.fillText(`${Math.round(min)} ft`, pad, h - 4);
  const range = $('#altRangeTxt');
  if (range) range.textContent = `Δ ${Math.round(max - min)} ft · ${pts.length} muestras`;
}

/* ------------------------------------------------------------------ */
/* Ajustes                                                             */
/* ------------------------------------------------------------------ */

function renderSourceToggles() {
  $('#sourceToggles').innerHTML = Object.entries(SOURCE_LABELS)
    .map(
      ([k, label]) => `<div class="switch-row">
        <div><div class="sr-label">${label}</div></div>
        <div class="switch ${state.cfg.sources[k] ? 'on' : ''}" data-source="${k}"></div>
      </div>`
    )
    .join('');
  $('#sourceToggles').querySelectorAll('.switch').forEach((el) => {
    el.addEventListener('click', () => {
      el.classList.toggle('on');
      state.cfg.sources[el.dataset.source] = el.classList.contains('on');
    });
  });
}

function openSettings() {
  $('#setRadius').value = state.cfg.radius;
  $('#vRadius').textContent = `${state.cfg.radius} km`;
  $('#setThreshold').value = state.cfg.threshold;
  $('#vThreshold').textContent = state.cfg.threshold;
  $('#setCeiling').value = state.cfg.ceiling;
  $('#vCeiling').textContent = `${fmtInt(state.cfg.ceiling)} ft`;
  $('#setInterval').value = state.cfg.interval;
  $('#vInterval').textContent = `${state.cfg.interval} s`;
  $('#setLat').value = state.center ? state.center.lat.toFixed(5) : '';
  $('#setLon').value = state.center ? state.center.lon.toFixed(5) : '';
  $('#swSound').classList.toggle('on', state.cfg.sound);
  $('#swFollow').classList.toggle('on', state.cfg.follow);
  $('#swShowAll').classList.toggle('on', state.cfg.showAll);
  renderSourceToggles();
  $('#settingsBackdrop').classList.add('open');
}

function applySettings() {
  state.cfg.radius = Number($('#setRadius').value);
  state.cfg.threshold = Number($('#setThreshold').value);
  state.cfg.ceiling = Number($('#setCeiling').value);
  state.cfg.interval = Number($('#setInterval').value);
  const lat = parseFloat($('#setLat').value);
  const lon = parseFloat($('#setLon').value);
  saveCfg();
  if (Number.isFinite(lat) && Number.isFinite(lon) && Math.abs(lat) <= 90 && Math.abs(lon) <= 180) {
    setCenter(lat, lon, 'manual');
  }
  if (state.scanning) {
    clearInterval(state.timer);
    state.timer = setInterval(scanOnce, state.cfg.interval * 1000);
  }
  $('#settingsBackdrop').classList.remove('open');
  renderAll();
  toast('Ajustes aplicados', `Radio ${state.cfg.radius} km · umbral ${state.cfg.threshold} · ${state.cfg.interval} s`, false);
}

/* ------------------------------------------------------------------ */
/* Eventos                                                             */
/* ------------------------------------------------------------------ */

function bindUI() {
  $('#btnScan').addEventListener('click', () => (state.scanning ? stopScan() : startScan()));

  $('#btnDemo').addEventListener('click', () => {
    state.demo = !state.demo;
    $('#chipMode').style.display = state.demo ? '' : 'none';
    $('#btnDemo').classList.toggle('primary', state.demo);
    if (state.demo && !state.scanning) startScan();
    if (!state.demo) {
      state.contacts = [];
      state.alerts = [];
      renderAll();
    }
    toast(state.demo ? 'Modo demostración' : 'Modo real', state.demo ? 'Se inyectan cinco trayectorias sintéticas para validar el detector.' : 'Volviendo a las fuentes abiertas.', false);
  });

  $('#btnSettings').addEventListener('click', openSettings);
  $('#settingsClose').addEventListener('click', () => $('#settingsBackdrop').classList.remove('open'));
  $('#settingsBackdrop').addEventListener('click', (e) => {
    if (e.target.id === 'settingsBackdrop') $('#settingsBackdrop').classList.remove('open');
  });
  $('#btnApply').addEventListener('click', applySettings);

  $('#btnReset').addEventListener('click', async () => {
    try {
      await fetch('/api/reset', { method: 'POST' });
      state.contacts = [];
      state.alerts = [];
      state.scoreHistory.clear();
      state.alertedAt.clear();
      renderAll();
      toast('Pistas reiniciadas', 'El historial cinemático se ha borrado.', false);
    } catch (_) { /* noop */ }
  });

  $('#setRadius').addEventListener('input', (e) => {
    $('#vRadius').textContent = `${e.target.value} km`;
    state.cfg.radius = Number(e.target.value);
    drawRadar();
  });
  $('#setThreshold').addEventListener('input', (e) => {
    $('#vThreshold').textContent = e.target.value;
    state.cfg.threshold = Number(e.target.value);
  });
  $('#setCeiling').addEventListener('input', (e) => {
    $('#vCeiling').textContent = `${fmtInt(Number(e.target.value))} ft`;
    state.cfg.ceiling = Number(e.target.value);
  });
  $('#setInterval').addEventListener('input', (e) => {
    $('#vInterval').textContent = `${e.target.value} s`;
    state.cfg.interval = Number(e.target.value);
  });

  $$('#swSound, #swFollow, #swShowAll').forEach((el) => {
    el.addEventListener('click', () => {
      el.classList.toggle('on');
      state.cfg[el.dataset.key] = el.classList.contains('on');
      saveCfg();
      if (el.dataset.key === 'showAll') renderAll();
    });
  });

  $$('.tab[data-view]').forEach((t) => {
    t.addEventListener('click', () => {
      $$('.tab[data-view]').forEach((x) => x.classList.remove('active'));
      t.classList.add('active');
      state.view = t.dataset.view;
      $('#viewRadar').classList.toggle('hidden', state.view !== 'radar');
      $('#viewMap').classList.toggle('hidden', state.view !== 'map');
      if (state.view === 'map') {
        initMap();
        setTimeout(() => {
          if (!state.map) return;
          state.map.invalidateSize();
          const c = state.center;
          if (c) state.map.setView([c.lat, c.lon], zoomForRadius(rangeKm()), { animate: false });
          renderMap();
        }, 60);
      } else {
        resizeRadar();
        drawRadar();
      }
    });
  });

  $$('.tab[data-side]').forEach((t) => {
    t.addEventListener('click', () => {
      $$('.tab[data-side]').forEach((x) => x.classList.remove('active'));
      t.classList.add('active');
      const side = t.dataset.side;
      $('#contactList').classList.toggle('hidden', side !== 'contacts');
      $('#alertList').classList.toggle('hidden', side !== 'alerts');
      $('#sourceList').classList.toggle('hidden', side !== 'sources');
      $('#listToolbar').style.display = side === 'contacts' ? '' : 'none';
    });
  });

  $$('.filter-btn').forEach((b) => {
    b.addEventListener('click', () => {
      $$('.filter-btn').forEach((x) => x.classList.remove('active'));
      b.classList.add('active');
      state.filter = b.dataset.filter;
      renderList();
      drawRadar();
    });
  });

  $('#drawerClose').addEventListener('click', closeDrawer);
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeDrawer();
      $('#settingsBackdrop').classList.remove('open');
    }
  });

  window.addEventListener('resize', () => {
    resizeRadar();
    drawRadar();
  });

  document.addEventListener('visibilitychange', () => {
    if (document.hidden && state.scanning) {
      clearInterval(state.timer);
      state.timer = null;
    } else if (!document.hidden && state.scanning && !state.timer) {
      state.timer = setInterval(scanOnce, state.cfg.interval * 1000);
      scanOnce();
    }
  });
}

/* ------------------------------------------------------------------ */
/* Arranque                                                            */
/* ------------------------------------------------------------------ */

async function boot() {
  bindUI();
  // Permite abrir directamente en demostración: ?demo=1
  if (new URLSearchParams(location.search).get('demo') === '1') {
    state.demo = true;
    const chip = $('#chipMode');
    if (chip) chip.style.display = '';
    $('#btnDemo')?.classList.add('primary');
  }
  resizeRadar();
  requestAnimationFrame(radarLoop);
  const ok = await initLocation();
  watchPosition();
  updateStatusbar();
  if (ok) {
    startScan();
  } else {
    $('#chipStatus').className = 'chip warn';
    $('#statusText').textContent = 'Esperando ubicación';
  }
  // Refresco del reloj de estado
  setInterval(() => {
    if (state.lastScanAt) {
      const age = Math.round((Date.now() - state.lastScanAt) / 1000);
      if (state.scanning && age > state.cfg.interval * 3) {
        $('#chipStatus').className = 'chip warn';
        $('#statusText').textContent = `Datos de hace ${age}s`;
      }
    }
  }, 3000);
}

boot();
