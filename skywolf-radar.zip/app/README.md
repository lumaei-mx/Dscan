# SkyWolf — escáner de UAS por firma cinemática

Aplicación web de vigilancia aérea local que usa la **ubicación del dispositivo como
centro del radar** y detecta **drones de carreras y UAS en general** a partir de su
**movimiento**, no de su identidad.

---

## 1. Por qué se ignora la identidad

El usuario lo dejó claro desde el principio: *los drones se están identificando como
naves comerciales y otras*. Un dron que emite ADS-B puede declarar el indicativo de
un Airbus, la matrícula de un Cessna o la categoría de un transporte pesado. Por eso
**ningún campo de identidad (hex, callsign, matrícula, tipo, categoría) participa en
la puntuación de riesgo**.

La identidad se conserva por dos motivos puramente operativos:

1. Mostrar al operador *qué dice ser* el contacto, para que pueda contrastarlo.
2. Alimentar el **módulo de suplantación**, que no premia ninguna identidad: sólo
   detecta la **contradicción** entre lo declarado y lo observado. Un contacto que
   dice ser un A320 y sostiene giros de 25 °/s a 250 ft AGL es, precisamente por esa
   incoherencia, más sospechoso que uno que no declara nada.

Es una diferencia importante: la identidad no es prueba de nada, pero su
incoherencia con la física sí es evidencia.

---

## 2. Qué se mide

El motor construye un historial por dirección ICAO de 24 bits y calcula derivadas
sobre él. Todas las magnitudes son cinemáticas:

| Magnitud | Cómo se obtiene | Por qué delata a un UAS |
|---|---|---|
| **Régimen de giro** (°/s) | Diferencia de rumbo entre tramos contiguos / Δt | Un ala fija sostenida rara vez supera 6–8 °/s; un FPV pasa de 25 °/s |
| **Reversiones de rumbo** | Cambios de signo del giro (≥4° para no contar ruido) | El slalom es la firma más limpia de un dron de carreras |
| **Aceleración lateral** (g) | v · ω / g con velocidad suavizada | Cuantifica la agresividad real de la maniobra |
| **Aceleración longitudinal** (kt/s) | Δv sobre ventanas ≥ 2 tramos | Un multirrotor acelera y frena en segundos |
| **Régimen vertical y jerk** (ft/min) | Δaltitud/Δt y su segunda diferencia | Subidas y frenadas verticales bruscas |
| **Hover** | Velocidad mediana ≤ 6 kt durante > 8 s | Un ala fija no puede quedarse quieta en el aire |
| **Techo AGL** | Altitud barométrica − elevación del terreno | Los UAS de largo alcance documentados llegan a 3000 ft o más |
| **Rectitud de la traza** | Desplazamiento neto / longitud recorrida | Patrones de patrulla y zigzag frente a aerovías rectas |
| **Coherencia velocidad declarada vs derivada** | gs del mensaje / velocidad de la traza | Detecta tanto emisores defectuosos como suplantación |

La elevación del terreno se consulta a Open-Meteo y se cachea 24 h, de modo que el
techo se evalúa **sobre el terreno (AGL)** y no sobre el nivel del mar. En Madrid
(≈2188 ft de altitud orográfica), 3000 ft AGL son ≈5200 ft barométricos: sin esta
corrección, cualquier dron a 3000 ft parecería estar a 800 ft.

### Puntuación

Cada evidencia suma puntos (0–100). Los umbrales de presentación son:

- **≥ 65** crítico
- **45–64** alto
- **28–44** medio
- **14–27** bajo
- **< 14** descartado (sigue dibujado en el radar, atenuado)

La puntuación se acompaña de una **confianza** basada en número de muestras y
tiempo cubierto, para que el operador sepa cuándo el veredicto es todavía joven.

### Perfiles (cinemáticos, sin identidad)

- Multirrotor / hover
- FPV de carreras
- Multirrotor ágil
- UAS de largo alcance (maniobras cerradas)
- Ala fija / ala delta
- Helicóptero / giroavión
- Aeronave tripulada (media / alta velocidad)
- UAS con identidad suplantada (cuando el módulo de suplantación ≥ 35)

---

## 3. Fuentes de datos

| Fuente | Estado | Notas |
|---|---|---|
| **OpenSky Network** (`/api/states/all`) | opcional | Requiere credenciales OAuth2 para uso sostenido. Sin ellas, el sandbox la ve como `timeout`. |
| **adsb.fi** (open data, dump1090) | operativa | Fuente principal en pruebas; incluye MLAT y TIS-B. |
| **adsb.lol** | intermitente | Devuelve HTTP 429 con frecuencia (límite de tasa). |
| **airplanes.live** | restringida | Devuelve HTTP 403 sin allowlist/contacto. |

Los cuatro formatos se normalizan a una forma común y se **deduplican por hex**,
conservando el registro más rico. Se anota qué sensores vieron el contacto
(ADS-B / MLAT / TIS-B) y si fue **sólo MLAT**, lo que suma 8 puntos: la
multilateración sin ADS-B es típica de emisores no certificados.

### Credenciales de OpenSky

```bash
export OPENSKY_CLIENT_ID="tu_client_id"
export OPENSKY_CLIENT_SECRET="tu_client_secret"
PORT=8090 node server.js
```

El token se cachea con 60 s de margen de seguridad.

### Presupuesto de barrido

Ninguna fuente puede retener la respuesta más de **4,5 s**; OpenSky tiene además un
límite propio de 3,5 s. El cliente refresca cada 4 s. Sin este presupuesto, un
OpenSky inalcanzable bloqueaba cada barrido 10 s y la interfaz parecía colgada.

---

## 4. Arquitectura

```
app/
├── server.js            servidor HTTP sin dependencias + API + modo demo
├── lib/
│   ├── sources.js       agregador multi-fuente, normalización, caché por celda
│   └── detector.js      TrackStore, analyzeTrack, assessSpoof, perfiles
├── public/
│   ├── index.html       estructura (radar, mapa, panel, drawer, ajustes)
│   ├── css/style.css    tema táctico oscuro
│   ├── js/app.js        radar PPI, Leaflet, listas, alertas, ajustes
│   └── manifest.webmanifest
└── tools/tune-demo.js   banco de calibración del detector
```

Sin dependencias npm: se usan `fetch`, `http` y `fs` nativos de Node 22. El frontend
es JavaScript plano y Canvas; Leaflet se carga desde unpkg.

### API

| Ruta | Descripción |
|---|---|
| `GET /api/scan?lat&lon&radius&ceiling&sources&demo` | Barrido y análisis completo |
| `GET /api/track?hex=` | Historial y análisis de una pista |
| `POST /api/reset` | Vacía el historial |
| `GET /api/health` | Estado, número de pistas, credenciales |

`/api/scan` devuelve, por contacto: datos normalizados, `analysis` (puntuación,
nivel, perfil, evidencias, métricas y `spoof`) y `trail` (últimas 40 posiciones).

---

## 5. Modo demostración

Inyecta seis trayectorias sintéticas definidas en metros y muestreadas por
diferencias finitas, con elevación real del terreno:

1. **FPV de carreras** — elipses cruzadas, giros de ~29 °/s.
2. **Multirrotor en hover** — estacionario con oscilación vertical.
3. **UAS de largo alcance a 3000 ft** — deriva lenta + zigzag cerrado, sensor MLAT.
4. **Dron suplantando un A320** — declara `IBE3174` / `EC-NXF` / `A320` con
   dirección de 24 bits fuera del espacio OACI (`adsb_other`).
5. **Ala fija tripulada (control)** — órbita limpia de 115 kt y 2,1 °/s.
6. **Helicóptero (control)** — círculo de 800 m de radio.

El historial se **precalienta con 88 s de pasado** al entrar en modo demo: el motor
necesita ~20 muestras para medir giros y reversiones con robustez, y sin esto los
drones aparecerían como "medio" durante el primer minuto y medio.

Resultado típico del banco de calibración:

```
FPV de carreras            crítico  100   FPV de carreras
UAS de largo alcance       crítico   92   UAS de largo alcance (maniobras cerradas)
Multirrotor en hover       alto      62   Multirrotor / hover
Dron suplantando A320      alto      50 + 58 suplantación
Helicóptero (control)      bajo      17   Aeronave tripulada (media velocidad)
Ala fija (control)         descartado 10  Aeronave tripulada (alta velocidad)
```

---

## 6. Robustez del dato

Tres salvaguardas evitan falsos positivos por calidad de la red:

1. **Posición congelada.** Si el emisor declara velocidad (> 3 kt) pero su posición
   no cambia entre barridos, la muestra no se guarda: es un informe repetido, no un
   objeto quieto.
2. **Trazas sin desplazamiento.** Menos de 3 posiciones distintas, o más de la mitad
   de los tramos congelados, marcan la pista como `sin-datos` y no se puntúa.
3. **Contactos en tierra.** `onGround` o altitud barométrica por debajo del terreno
   desactivan tanto el premio por vuelo bajo como el módulo de suplantación. Sin
   esto, todo el tráfico de rodadura de Barajas aparecía como "suplantación".

También se usa la **mediana de los tres mayores** valores (`robustMax`) en giro,
aceleración, régimen vertical y jerk, de modo que un único pico no dispare una alerta.

---

## 7. Límites conocidos

- **Un helicóptero en hover y un multirrotor en hover son cinemáticamente
  indistinguibles.** El motor los marca a ambos; la identidad declarada no se usa
  para desempatar porque es justamente lo que se quiere ignorar.
- **Aproximaciones normales** son rápidas y bajas. El premio por "rápido y bajo"
  exige además maniobra cerrada (≥ 8 °/s) para no marcar a todo el tráfico en final.
- **Cobertura**: sólo se ve lo que las redes reciben. Un dron sin ADS-B, sin
  transpondedor y fuera del alcance de los receptores MLAT es invisible para
  cualquier escáner pasivo. Este proyecto **no** usa WiFi ni Bluetooth, tal como se
  pidió: los drones objetivo no emiten esas señales.
- **OpenSky desde el sandbox** no es alcanzable por red; en un despliegue normal con
  credenciales funciona. La app degrada a las redes abiertas sin romperse.

---

## 8. Ejecución

```bash
cd app
PORT=8090 node server.js
# abrir http://localhost:8090        (modo real)
# abrir http://localhost:8090/?demo=1 (modo demostración)
```

El navegador pedirá permiso de ubicación; si se deniega, se usa Madrid como centro
de respaldo y puede fijarse manualmente en Ajustes.

### Atajos

- `Espacio` — iniciar / pausar el barrido
- Clic en un contacto — panel de detalle con cinemática, perfil de altitud,
  evidencias y bloque de suplantación
- Filtros: Todos / Críticos / Altos / Perfil UAS / Suplantación
